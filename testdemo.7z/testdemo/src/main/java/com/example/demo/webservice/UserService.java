package com.example.demo.webservice;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public  UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<User> findAllUsers() {
        List<User> users = new ArrayList<>();
        Iterable<User> results = this.userRepository.findAll();
        results.forEach(user -> {users.add(user);});
        return users;
    }
    @Transactional
    public void deleteByNames(List<String> names) {
        userRepository.deleteUserByNameIn(names);
    }
    public Optional<User> findByName(String name) {
        return userRepository.findUserByName(name);
    }

    @Transactional
    public void deleteByName(String name) {
        userRepository.deleteUserByName(name);
    }

    public User saveUser(User user) {
        return userRepository.save(user);
    }
}
