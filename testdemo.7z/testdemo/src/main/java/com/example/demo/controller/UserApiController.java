package com.example.demo.controller;

import com.example.demo.entity.User;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import com.example.demo.webservice.MailService;
import com.example.demo.webservice.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;

@RestController
@RequestMapping("/api")
class UserApiController {

    private final UserService userService;
    private final MailService mailService;

    @Autowired
    public UserApiController(UserService userService, MailService mailService) {
        this.userService = userService;
        this.mailService = mailService;
    }

    @GetMapping(value = "/users")
    ResponseEntity<List<User>> findAll() {
        return ResponseEntity.ok(userService.findAllUsers());
    }

    @DeleteMapping(value = "/users")
    ResponseEntity<String> deleteByNames(@RequestBody List<String> names) {
        userService.deleteByNames(names);
        return ResponseEntity.ok("delete success");
    }

    @GetMapping("/user/{name}")
    public ResponseEntity<User> retrieveUser(@PathVariable String name) {
        Optional<User> user = this.userService.findByName(name);
        if (!user.isPresent()) {
            return ResponseEntity.notFound().build();//.badRequest().build();
        }
        return ResponseEntity.ok(user.get());
    }

    @DeleteMapping("/user/{name}")
    public void deleteUser(@PathVariable String name) {
        userService.deleteByName(name);
    }

    @PostMapping("/user")
    public ResponseEntity<Object> createUser(@RequestBody User user) {
        Optional<User> u = this.userService.findByName(user.getName());
        if (u.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
        User new_user = this.userService.saveUser(user);
        if (null != new_user) {
            mailService.sendEmail(new_user);
        }
        else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{name}")
                .buildAndExpand(new_user.getName()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/user/{name}")
    public ResponseEntity<User> updateUser(@PathVariable String name, @Valid @RequestBody User user) {
        Optional<User> userOptional = userService.findByName(name);
        if (!userOptional.isPresent())
            return ResponseEntity.notFound().build();
        return ResponseEntity.ok(userService.saveUser(user));
    }
}
